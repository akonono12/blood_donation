    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="Donor_inbox.php">Blood Donation Management and Information System </a>
            </div>
          
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
				<li><a href="admin_inbox.php">	BACK</a></li>
                  
                </ul>
            </div>
        </div>
        <!-- /.container -->
    </nav>