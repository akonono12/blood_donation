<?php include"config.php";?>
<html>
<?php include"head.php";?>
<body>

<?php
	 include"top_nav.php";
?>
		
				<div class="container" style="margin-top:40px;">
                <center><h1>ABOUT BLOOD DONATION</h1><center>
                <p>Blood donation is considered as a method of healing that can not be manufactured. It can only be taken on people with care to give their time to dedicate their blood to save other people.</p>
				</div></br>
				
				
				
				<div class="container">
				<div class="col-md-6">
				<br>
				<br>
                <h1>WHO NEEDS BLOOD</h1><br><br>
                <h4>1. Patients with serious lack of blood.<br><br>
				2. With leukemia or hemophilia.<br><br>
				3. Those who have had complications.<br><br>
				4. Who met accidents.<br><br>
				5. Need to be transplanted.<br></h4>
				
                
            </div>
		<div class="row">
            <div class="col-md-6">
			<br><br><br>
                <img class="img-responsive" src="images/contact.jpg" alt="">
            </div>
        </div>
		
		</div>
		
		<br>
		<br>
		
		<div class="container">
		 <div class="row">
            <div class="col-md-6">
			<br><br><br>
                <img class="img-responsive" src="images/contact.jpg" alt="">
            </div>
            <div class="col-md-6">
			<br>
			<br>
               <h1>WHO CAN GIVE BLOOD</h1>
                <h4>Common characteristics of potential "blood donors":<h4>
				<br>
				<h4>1. Weighing 110 lbs / 50 kg.<br><br>
				2. Age: 18-60 years old or up to 65 years old to regular blood donors.<br><br>
				3. Healthy.<br><br>
				
				
            </div>
			
        </div>
		</div>
		
		
		
	
		<br>
		<br>
		
		
		<div class="container">
				<div class="col-md-6">
				<br>
				<br>
                <h1>HOW OFTEN CAN GIVE BLOOD</h1><br><br>
                <h4>1. To Male: 3 months after giving blood.<br><br>
				2. To Female: 4 months after giving blood.<br><br>
				
				
                
            </div>
		<div class="row">
            <div class="col-md-6">
			<br><br><br>
                <img class="img-responsive" src="images/contact.jpg" alt="">
            </div>
        </div>
		
		</div>
		
		
		
		<br>
		<br>
		
		
		
		
		<div class="container">
		 <div class="row">
            <div class="col-md-6">
			<br><br><br>
                <img class="img-responsive" src="images/contact.jpg" alt="">
            </div>
            <div class="col-md-6">
			<br>
			<br>
               <h1>WHERE TO DONATE BLOOD</h1><br>
				<h4>1.BICOL REGIONAL BLOOD CENTER(BRBC), Legazpi City<br><br>
				2. BICOL MEDICAL CENTER(BMC), Naga City<br><br>
				3. PHILIPPINE RED CROSS (Masbate, Catanduanes & Naga City Chapters)<br>
				<br><br>Or "Mobile Blood Donations" that are held in the following:</br><br>
				
				<br>1. Municipal/City Health Offices<br><br>
				2. Schools/Universities<br><br>
				3. Government Offices and Other Sectors<br><br>
				</h4>
            </div>
			
        </div>
		</div>
		
		
		
		
		
		

</body>

</html>
