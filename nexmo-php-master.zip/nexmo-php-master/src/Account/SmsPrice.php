<?php

namespace Nexmo\Account;

class SmsPrice extends Price {
    protected $priceMethod = 'getOutboundSmsPrice';
}
